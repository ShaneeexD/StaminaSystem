# StaminaSystem by ShaneeexD

Adds a brand new stamina system into the game.

Includes config options:
- Drain speed
- Regain speed
- Jump drain amount
- Minimum stamina in order to be able to run/jump again
- Enable/disable visible stamina bar

# Source code:

https://github.com/ShaneeexD/StaminaSystem