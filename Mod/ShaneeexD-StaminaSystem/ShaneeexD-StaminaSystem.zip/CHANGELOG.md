# 1.0.0

* Initial release.

# 1.0.1

* Optimisations.

# 1.0.2

* Fixed bug where the visible bar could not be turned off.
* Another small optimisation.
